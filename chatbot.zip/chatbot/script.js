// ======================================
// CHATBOT PROJECT
// ======================================


// Send message

function sendMessage() {

    const input = document.getElementById("userInput");

    const message = input.value.trim();

    if (message === "") {
        return;
    }

    // Display user's message

    addMessage(message, "user");

    // Get chatbot response

    const response = getBotResponse(message);

    // Display bot response after small delay

    setTimeout(function () {

        addMessage(response, "bot");

    }, 500);

    // Clear input

    input.value = "";

}


// ======================================
// ADD MESSAGE TO CHAT
// ======================================

function addMessage(message, sender) {

    const chatBox = document.getElementById("chatBox");

    const messageDiv = document.createElement("div");

    messageDiv.classList.add("message");

    if (sender === "user") {

        messageDiv.classList.add("user-message");

        messageDiv.innerHTML =
            "<strong>You:</strong> " + message;

    } else {

        messageDiv.classList.add("bot-message");

        messageDiv.innerHTML =
            "<strong>Bot:</strong> " + message;

    }

    chatBox.appendChild(messageDiv);

    // Automatically scroll down

    chatBox.scrollTop = chatBox.scrollHeight;

}


// ======================================
// CHATBOT RESPONSE SYSTEM
// ======================================

function getBotResponse(message) {

    const text = message.toLowerCase();


    // Greeting

    if (
        text.includes("hello") ||
        text.includes("hi") ||
        text.includes("hey")
    ) {

        return "Hello! 👋 Nice to meet you.";

    }


    // How are you

    if (text.includes("how are you")) {

        return "I am doing great! Thank you for asking.";

    }


    // Name

    if (text.includes("your name")) {

        return "My name is AI Chatbot.";

    }


    // Who are you

    if (
        text.includes("who are you") ||
        text.includes("what are you")
    ) {

        return "I am a simple chatbot created using HTML, CSS and JavaScript.";

    }


    // Help

    if (text.includes("help")) {

        return "Sure! You can ask me about myself, chatbot technology, or say hello.";

    }


    // Chatbot

    if (text.includes("chatbot")) {

        return "A chatbot is a software application that communicates with users using natural language.";

    }


    // Programming

    if (
        text.includes("programming") ||
        text.includes("coding")
    ) {

        return "Programming is the process of creating instructions for computers using programming languages.";

    }


    // Thank you

    if (
        text.includes("thank you") ||
        text.includes("thanks")
    ) {

        return "You're welcome! 😊";

    }


    // Bye

    if (
        text.includes("bye") ||
        text.includes("goodbye")
    ) {

        return "Goodbye! 👋 Have a nice day.";

    }


    // Default response

    return "I'm sorry, I don't understand that yet. Please try another question.";

}


// ======================================
// ENTER KEY
// ======================================

document
    .getElementById("userInput")
    .addEventListener("keydown", function(event) {

        if (event.key === "Enter") {

            sendMessage();

        }

    });